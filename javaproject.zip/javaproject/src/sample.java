//import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class sample {
	static Connection con = null;
	static PreparedStatement p = null;
	static ResultSet rs = null;
	// getting aadhar id(manually)
	//static Scanner sc = new Scanner(System.in);
	static String name = "";
	static String id = "";
	static String mail = "";
	static String ph = "";
	static String Product = "";
	//static String aadno = "";
	static String address = "";
	static String pan = "";
	// String profile="";
	static String type = "";
	static String DOB = "";
	static int flag = 0;

	public static void main(String[] args) throws ClassNotFoundException{

		
			
			try {
				Class.forName("org.postgresql.Driver");
				con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Customers", "postgres", "postgres");
				System.out.println("database connected" + "\n\n");
Scanner sc=new Scanner(System.in);
				String aad = sc.next();

				String sql = "select *from cust1 where Aadhar_id=" + aad;
//System.out.println("Hi");
				p = con.prepareStatement(sql);
				rs = p.executeQuery();

//				while (rs.next()) {
//
//					System.out.println("****Customer details gets automaticaly filled in the form***");
//					System.out.println("Name : " + rs.getString("Name") + "\n" + "DOB :" + rs.getString("DOB") + "\n"
//							+ "Email :" + rs.getString("Email") + "\n" + "mobile :" + rs.getString("Mobile") + "\n"
//							+ "PAN : " + "\n" + rs.getString("PAN") + "\n" + "Aadhar no :" + "\n" + rs.getString("id")
//							+ "address no " + rs.getString("address") + "Product :" + "\n" + rs.getString("product")
//							+ "\n" + "profile : Existing \\n");
//					flag = 1;
//
//				}

				if (flag == 0) {
					System.out.println("****Customer fills the form***");
					System.out.println("name:  ");
					name = sc.next();
					System.out.println("mail:  ");
					mail = sc.nextLine();
					System.out.println("Contact:  ");
					ph = sc.nextLine();
					System.out.println("Product:  ");
					type = sc.nextLine();
					System.out.println("income:  ");
					pan = sc.nextLine();
					System.out.println("Product:  ");
					Product = sc.nextLine();

					String insertQuery = "insert into cust1 values (?,?,?,?,?,?,?)";
					int insertStatus = 0;
					
						p = con.prepareStatement(insertQuery);
						p.setString(1, name);
						p.setString(2, DOB);

						p.setString(3, aad);
						p.setString(4, pan);
						p.setString(5, ph);
						p.setString(6, mail);
						p.setString(7, Product);
						// p.setString(7,pro );

						// insertStatus = p.executeUpdate();
				}

				}
					catch (Exception e) {
						System.out.println("Exception in Insert:" + e.getMessage());
					}

		

			
		
	}
}

