package com.scb.cards;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Database {
	static Connection con = null;
	static PreparedStatement p = null;
	static ResultSet rs = null;
	// getting aadhar id(manually)
	// static Scanner sc = new Scanner(System.in);
	static String name = "";
	//static String id = "";
	static String mail = "";
	static String ph = "";
	static String Product = "";
	// static String aadno = "";
	static String address = "";
	static String pan = "";
	// String profile="";
	static String type = "";
	static String DOB = "";
	static int flag = 0;

	public static void main(String[] args) throws ClassNotFoundException {

		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Customers", "postgres", "postgres");
			System.out.println("database connected" + "\n\n");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your aadhar no:");

			int aad = sc.nextInt();

		 	String sql = "select *from cust1 where aadhar="+aad;
			p = con.prepareStatement(sql);
			rs = p.executeQuery();
       
			while (rs.next()) {

				System.out.println("****Customer details gets automaticaly filled in the form***");
				System.out.println("Name : " + rs.getString("Name") + "\n" + "DOB :" + rs.getString("DOB") + "\n"
						+ "Email :" + rs.getString("Email") + "\n" + "mobile :" + rs.getString("Mobile") + "\n"
						+ "PAN : " + rs.getString("PAN") + "\n" + "Aadhar no :" + rs.getInt("aadhar") + "\n"
						+ "Product :" + rs.getString("product") + "\n" + "profile : Existing");
				flag = 1;

			}

			if (flag == 0) {
				System.out.println("****Customer fills the form***");
				System.out.println("name:  ");
				name = sc.next();
				System.out.println("DOB:  ");
				DOB = sc.next();
	
				System.out.println("mail:  ");
				mail = sc.next();
				System.out.println("Contact:  ");
				ph = sc.next();
				System.out.println("Account:  ");
				type = sc.next();
				System.out.println("income:  ");
				pan = sc.next();
				System.out.println("Product:  ");
				Product = sc.next();

				String insertQuery = "insert into cust1(\"Name\",\"DOB\",\"PAN\",\"Mobile\",\"Email\",\"Product\",\"aadhar\") values (?,?,?,?,?,?,?)";
				int insertStatus = 0;

				p = con.prepareStatement(insertQuery);
				p.setString(1, name);
				p.setString(2, DOB);

				
				p.setString(3, pan);
				p.setString(4, ph);
				p.setString(5, mail);
				p.setString(6, Product);
				p.setInt(7, aad);
				p.executeUpdate();
				// p.setString(7,pro );

				// insertStatus = p.executeUpdate();
				
			//if delete button is pressed the corresponding row details will be taken out from the json file and 	
				
			}

		} catch (Exception e) {
			System.out.println("Exception in Insert:" + e.getMessage());
			e.printStackTrace();
		}

	}

}
