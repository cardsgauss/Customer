package com.scb.gauss.project.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.scb.gauss.project.common.Utilities;
import com.scb.gauss.project.dao.ApplicationDAOimpl;
import com.scb.gauss.project.dao.ApplicationTableDAO;

//import javax.rmi.CORBA.Util;

//import com.scb.gauss.project.common.Utilities;
import com.scb.gauss.project.dao.CustomerDAO;
import com.scb.gauss.project.dao.CustomerDAOimpl;
import com.scb.gauss.project.model.Application;
import com.scb.gauss.project.model.Customer;

public class Starter {

	static CustomerDAO customerDAO = new CustomerDAOimpl();
	static ApplicationTableDAO applicationDAO = new ApplicationDAOimpl();
	static int id;
	static String name1 = "";
	static String status = "";
	static int age;
	static String handledby = "";
	static String name = "";
	static String mail = "";
	static String contact;
	static String type = "";
	static String PAN = "";
	static String DOB = "";
	static int aadhar;
	static Application a = new Application();
	static Customer c = new Customer();
	static Scanner sc = new Scanner(System.in);

	public static void main(String args[]) throws SQLException {
		int aad = 0;
		int choice;
		applicationDAO.connection();
		boolean ans;
		System.out.println("Enter Aadhar number:");
		aad = sc.nextInt();
		String sql = "SELECT * FROM \"cust1\" WHERE aadhar=" + aad;

		// insertion
		ans = applicationDAO.check(sql);
		System.out.println("ans : "+ans);
		int b;
		if (!ans) {
			do {
				System.out.println("\t\t\t\t\t\t" + "***********Welcome to scb***********" + "\n");
				System.out.println("Services offered:" + "\n");
				System.out.println("1.Connect to the Database :" + "\n");
				System.out.println("2.Insert Customer Details :" + "\n");
				System.out.println("3.Update Customer Details :" + "\n");
				System.out.println("4.Delete a customer record" + "\n");
				System.out.println("5.Display all records:" + "\n");
				System.out.println("6.Exit" + "\n");
				System.out.println("Enter your service number:" + "\n");

				b = sc.nextInt();

				switch (b) {
				case 1: {
					connect();
					break;
				}

				case 2: {

					insert();
					break;

				}
				case 3: {
					update();
					break;
				}

				case 4: {

					delete();
					break;
				}

				case 5: {
					showall();
					break;

				}

				case 6: {

					Utilities.closeResources();
					System.exit(0);

				}

				}

			} while (b != 7);

		} else {
			do {
				System.out.println("\t\t\t\t\t\t" + "***********Welcome to scb***********" + "\n");
				System.out.println("Services offered:" + "\n");
				System.out.println("1.Connect to the Database :" + "\n");
				System.out.println("2.Create Application :" + "\n");
				System.out.println("3.Update Appliaction Details :" + "\n");
				System.out.println("4.Delete a customer record" + "\n");
				System.out.println("5.Display the Application Table" + "\n");
				System.out.println("6.Exit" + "\n");
				System.out.println("Enter your service number:" + "\n");

				b = sc.nextInt();

				switch (b) {
				case 1: {
					connect();
					break;
				}

				case 2: {

					insert();
					break;

				}
				case 3: {
					update1();
					break;
				}

				case 4: {

					delete1();
					break;
				}

				case 5: {
					showall1();
					break;

				}

				case 6: {

					Utilities.closeResources();
					System.exit(0);

				}

				}

			} while (b != 6);

		}

	}

	/*
	 * c.setName("srini"); c.setMail("asdf"); c.setContact(32523);
	 * c.setType("savings"); c.setId(5); int insertstatus = 0; insertstatus =
	 * customerDAO.insert(c); if (insertstatus > 0) {
	 * System.out.println("successfully inserted"); }
	 * 
	 * // updation
	 * 
	 * c.setName("sadsda"); c.setMail("asdsadf"); c.setContact(32333);
	 * c.setType("savings"); c.setId(4); int updatestatus = 0; updatestatus =
	 * customerDAO.update(1, c); if (updatestatus > 0) {
	 * System.out.println("successfully updated"); }
	 * 
	 * // deletion
	 * 
	 * int deleteStatus = 0; deleteStatus = customerDAO.delete(3); if (deleteStatus
	 * > 0) { System.out.println("successfully deleted"); }
	 * 
	 * // display all List<Customer> CustomerList = new ArrayList<Customer>();
	 * CustomerList = customerDAO.displayall();
	 * System.out.println("Displaying all records");
	 * System.out.println("-------------------"); for (Customer cust : CustomerList)
	 * { System.out.println(cust); }
	 * 
	 * // display Customer c1 = customerDAO.display(1); System.out.println(c1);
	 * 
	 * Utilities.closeResources();
	 * 
	 * 
	 * 
	 */
	static void connect() {
		customerDAO.connection();
		applicationDAO.connection();
	}

	static void insert() {
		System.out.println("name:  ");
		name = sc.next();
		System.out.println("email:  ");
		mail = sc.next();
		System.out.println("Contact:  ");
		contact = sc.next();
		System.out.println("Account Type:  ");
		type = sc.next();
		System.out.println("PAN :");
		PAN = sc.next();
		System.out.println("DOB :");
		DOB = sc.next();
		System.out.println("aadhar :");
		aadhar = sc.nextInt();

		c.setName(name);
		c.setPAN(PAN);
		c.setContact(contact);
		c.setType(type);
		c.setAadhar(aadhar);
		c.setDOB(DOB);
		c.setMail(mail);
		int insertstatus = 0;
		int insertstatus1 = 0;
		insertstatus = customerDAO.insert(c);
		id = customerDAO.gettId(aadhar);

		applicationDAO.insert(name, id);
		if (insertstatus > 0) {
			System.out.println("successfully inserted");
		}

	}

	/*
	 * static void show() { System.out.println("Enter the id :"); int i =
	 * sc.nextInt(); Customer c1 = customerDAO.display(i); System.out.println(c1); }
	 */

	static void showall() {
		List<Customer> CustomerList = new ArrayList<Customer>();
		CustomerList = customerDAO.displayall();
		System.out.println("Displaying all records");
		System.out.println("-------------------");
		for (Customer cust : CustomerList) {
			System.out.println(cust);
		}
	}

	static void update() {
		System.out.println("Enter the id :");
		int i = sc.nextInt();

		System.out.println("name:  ");
		name = sc.next();
		System.out.println("email:  ");
		mail = sc.next();
		System.out.println("Contact:  ");
		contact = sc.next();
		System.out.println("Account Type:  ");
		type = sc.next();
		c.setName(name);
		c.setMail(mail);
		c.setContact(contact);
		c.setType(type);
		// c.setId(4);
		int updatestatus = 0;
		updatestatus = customerDAO.update(i, c);
		if (updatestatus > 0) {
			System.out.println("successfully updated");
		}
	}

	static void delete() {
		System.out.println("Enter the id :");
		int i = sc.nextInt();
		int deleteStatus = 0;
		deleteStatus = customerDAO.delete(i);
		if (deleteStatus > 0) {
			System.out.println("successfully deleted");
		}

	}

	static void showall1() {
		List<Application> ApplicationList = new ArrayList<Application>();
		ApplicationList = applicationDAO.displayall();
		System.out.println("Displaying all records");
		System.out.println("-------------------");
		for (Application app : ApplicationList) {
			System.out.println(app);
		}

	}

	static void update1() {
		System.out.println("Enter the Applicarion id :");
		int i = sc.nextInt();

		System.out.println("name:  ");
		name1 = sc.next();
		System.out.println("Status of the application :  ");
		status = sc.next();
		System.out.println("age of the application:  ");
		age = sc.nextInt();
		System.out.println("Handledby:  ");
		handledby = sc.next();

		a.setAppName(name1);
		a.setAppStatus(status);
		a.setAppAge(age);
		a.setHandledBy(handledby);
		// c.setId(4);
		int updatestatus = 0;
		updatestatus = applicationDAO.update(i, a);
		if (updatestatus > 0) {
			System.out.println("successfully updated");
		}

	}

	static void delete1() {
		System.out.println("Enter the id :");
		int i = sc.nextInt();
		int deleteStatus = 0;
		deleteStatus = applicationDAO.delete(i);
		if (deleteStatus > 0) {
			System.out.println("successfully deleted");
		}

	}

}
