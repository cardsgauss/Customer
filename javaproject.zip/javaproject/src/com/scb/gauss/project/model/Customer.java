package com.scb.gauss.project.model;

public class Customer {
	private String name;
	private String DOB;
	private String PAN;
	private String mail;
	private String contact;
	private String type;
	private int id; 
	private int aadhar;
	
	public Customer(String name, String dOB, String pAN, String mail, String contact, String type, int id, int aadhar) {
		super();
		this.name = name;
		this.DOB = dOB;
		this.PAN = pAN;
		this.mail = mail;
		this.contact = contact;
		this.type = type;
		this.id = id;
		this.aadhar = aadhar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAadhar() {
		return aadhar;
	}

	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}

	public Customer() {
		super();
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", DOB=" + DOB + ", PAN=" + PAN + ", mail=" + mail + ", contact=" + contact
				+ ", type=" + type + ", id=" + id + ", aadhar=" + aadhar + "]";
	}

	
	


}
