package com.scb.gauss.project.model;

public class Application {
	private int appId;
	private String appName = "";
	private String appStatus = "";
	private int appAge;
	private String handledBy = "";

	public Application(int appId, String appName, String appStatus, int appAge, String handledBy) {
		super();
		this.appId = appId;
		this.appName = appName;
		this.appStatus = appStatus;
		this.appAge = appAge;
		this.handledBy = handledBy;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}

	public int getAppAge() {
		return appAge;
	}

	public void setAppAge(int appAge) {
		this.appAge = appAge;
	}

	public String getHandledBy() {
		return handledBy;
	}

	public void setHandledBy(String handledBy) {
		this.handledBy = handledBy;
	}

	public Application() {
		super();
	}

	@Override
	public String toString() {
		return "Application [appId=" + appId + ", appName=" + appName + ", appStatus=" + appStatus + ", appAge="
				+ appAge + ", handledBy=" + handledBy + "]";
	}
	
	
	

}
