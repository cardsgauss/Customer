package com.scb.gauss.project.common;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Utilities {
	static Connection con = null;
	static PreparedStatement p;
	static ResultSet rs;

	public static Connection connect() {
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Customers", "postgres", "postgres");
			System.out.println("database connected" + "\n\n");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Connection error");
			e.printStackTrace();
		}
		return con;
	}

	public static void closeResources() {
		try {
			if (rs != null)
				rs.close();

			if (p != null)
				p.close();
			if (con != null)
				con.close();
		} catch (Exception e) {
			System.out.println("Exception in close:" + e.getMessage());
		}

	}

}
