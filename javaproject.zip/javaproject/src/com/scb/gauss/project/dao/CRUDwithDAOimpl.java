package com.scb.gauss.project.dao;

import java.util.List;

import com.scb.gauss.project.model.Customer;

public class CRUDwithDAOimpl implements CRUDwithDAO {

	@Override
	public List<Customer> displayall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer display(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Customer c) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(int id, Customer c) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int customerID) {
		// TODO Auto-generated method stub
		return 0;
	}

}
