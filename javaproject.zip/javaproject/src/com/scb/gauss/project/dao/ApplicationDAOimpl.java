package com.scb.gauss.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.scb.gauss.project.common.Utilities;
import com.scb.gauss.project.model.Application;
//import com.scb.gauss.project.model.Application;
import com.scb.gauss.project.model.Customer;

public class ApplicationDAOimpl implements ApplicationTableDAO {

	private Connection con = null;
	private PreparedStatement p = null;
	private ResultSet rs = null;
	private Statement st = null;
	static int id;
	static String name = "";

	@Override
	public List<Application> displayall() {

		List<Application> customerList = new ArrayList<Application>();

		String query = "select * from \"applicationTable\"";
		try {
			this.st = this.con.createStatement();
			this.rs = this.st.executeQuery(query);
			while (rs.next()) {
				Application c = new Application();
				c.setAppId(rs.getInt("application_id"));
				c.setAppName(rs.getString("application_name"));
				c.setAppStatus(rs.getString("application_status"));
				c.setAppAge(rs.getInt("age_of_application"));
				c.setHandledBy(rs.getString("handled_by"));
				customerList.add(c);

			}
		} catch (Exception e) {
			System.out.println("Exception in displayAll:" + e.getMessage());
		}
		return customerList;
	}

	@Override
	public int insert(String name, int id) {
		String insertQuery = "insert into \"applicationTable\" values(?,?,?,?,?)";
		int insertStatus = 0;

		try {
			p = con.prepareStatement(insertQuery);
			p.setInt(1, id);
			p.setString(2, name);
			p.setString(3, "pending");
			p.setInt(4, 0);
			p.setString(5, "suresh");
			// p.setInt(6,9);

			insertStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in Insert:");
			e.printStackTrace();
		}

		return insertStatus;

	}

	@Override
	public int update(int id, Application c) {
		String updateQuery = "UPDATE \"applicationTable\"  SET application_name=?, application_status=?, age_of_application=?, handled_by=? where application_id=?";
		int updateStatus = 0;
		try {
			p = con.prepareStatement(updateQuery);
			p.setString(1, c.getAppName());
			p.setString(2, c.getAppStatus());
			p.setInt(3, c.getAppAge());
			p.setString(4, c.getHandledBy());
			p.setInt(5, id);
			updateStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in Update:" + e.getMessage());
			e.printStackTrace();
		}
		return updateStatus;
	}

	@Override
	public int delete(int id) {
		String deleteQuery = "delete from  \"applicationTable\"  where application_id=?";
		int deleteStatus = 0;
		try {
			p = con.prepareStatement(deleteQuery);
			p.setInt(1, id);
			deleteStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in delete:" + e.getMessage());
		}
		return deleteStatus;
	}

	public boolean check(String query) {
		boolean ans = false;
		

		try {

			p = con.prepareStatement(query);
			rs = p.executeQuery();
			if (rs.next()) {
				ans=true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return ans;

	}

	@Override
	public void connection() {
		this.con = Utilities.connect();

	}

}
