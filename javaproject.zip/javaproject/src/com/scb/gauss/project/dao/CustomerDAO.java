package com.scb.gauss.project.dao;

import java.util.List;

import com.scb.gauss.project.model.Customer;

public interface CustomerDAO {

	 public List<Customer>  displayall();
	   //public Customer display(int id);
	   public int insert(Customer c);
	   public int update(int id,Customer c);
	   public int delete(int id);
	   public int gettId(int aadhar);
	   public void connection();
}
