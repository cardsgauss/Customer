package com.scb.gauss.project.dao;

import java.util.List;

import com.scb.gauss.project.model.Application;
import com.scb.gauss.project.model.Customer;

public interface ApplicationTableDAO {
	public List<Application>  displayall();
	  // public Customer display(int id);
	   public int insert(String a,int id);
	   public int update(int id,Application a);
	   public int delete(int id);
	   public boolean check(String sql);
	  // public void sendId(int id,String name);
	   
	   public void connection();
}
