package com.scb.gauss.project.dao;

import java.util.*;

import com.scb.gauss.project.model.Customer;

public interface CRUDwithDAO {
   public List<Customer>  displayall();
   public Customer display(int id);
   public int insert(Customer c);
   public int update(int id,Customer c);
   public int delete(int customerID);
}
