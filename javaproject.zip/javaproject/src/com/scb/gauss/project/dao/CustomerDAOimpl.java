package com.scb.gauss.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.scb.gauss.project.common.Utilities;
import com.scb.gauss.project.model.Customer;

public class CustomerDAOimpl implements CustomerDAO {
	private Connection con = null;
	private PreparedStatement p = null;
	private ResultSet rs = null;
	private Statement st = null;

	@Override
	public void connection() {
		// TODO Auto-generated method stub
		this.con = Utilities.connect();
	}

	@Override
	public List<Customer> displayall() {

		List<Customer> customerList = new ArrayList<Customer>();

		String query = "select * from cust1";
		try {
			this.st = this.con.createStatement();
			this.rs = this.st.executeQuery(query);
			while (rs.next()) {
				Customer c = new Customer();
				c.setName(rs.getString("Name"));
				c.setMail(rs.getString("Email"));
				c.setDOB(rs.getString("DOB"));
				c.setContact(rs.getString("Mobile"));
				c.setPAN(rs.getString("PAN"));
				c.setType(rs.getString("Product"));
				c.setId(rs.getInt("cust_id"));
				c.setAadhar(rs.getInt("aadhar"));
				customerList.add(c);

			}
		} catch (Exception e) {
			System.out.println("Exception in displayAll:" + e.getMessage());
		}
		return customerList;

	}

	/*
	 * public Customer display(int id) { Customer c1 = new Customer(); String query
	 * = "select * from cust where cust_id=" + id; try { this.st =
	 * this.con.createStatement(); this.rs = this.st.executeQuery(query); while
	 * (rs.next()) { c1.setName(rs.getString("name"));
	 * c1.setMail(rs.getString("mail")); c1.setContact(rs.getInt("contact"));
	 * c1.setType(rs.getString("type")); } } catch (Exception e) {
	 * System.out.println("Exception in display:" + e.getMessage()); } return c1; }
	 */

	@Override
	public int insert(Customer c) {

		String insertQuery = "insert into \"cust1\"(\"Name\",\"DOB\",\"PAN\",\"Mobile\",\"Email\",\"Product\",\"aadhar\") values (?,?,?,?,?,?,?)";
		int insertStatus = 0;
		try {
			p = con.prepareStatement(insertQuery);
			p.setString(1, c.getName());
			p.setString(2, c.getDOB());
			p.setString(3, c.getPAN());
			p.setString(4, c.getContact());
			p.setString(5, c.getMail());
			p.setString(6, c.getType());
			p.setInt(7, c.getAadhar());

			insertStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in Insert:" + e.getMessage());
		}

		return insertStatus;

	}

	@Override
	public int update(int id, Customer c) {
		String updateQuery = "update \"cust1\"  SET \"Name\"=?, \"DOB\"=?, \"PAN\"=?, \"Mobile\"=?,\"Email\"=?, \"Product\"=?, \"aadhar\"=? where \"cust_id\"=?";
		int updateStatus = 0;
		try {
			p = con.prepareStatement(updateQuery);
			p.setString(1, c.getName());
			p.setString(2, c.getDOB());
			p.setString(3, c.getPAN());
			p.setString(4, c.getContact());
			p.setString(5, c.getMail());
			p.setString(6, c.getType());
			p.setInt(7, c.getAadhar());
			p.setInt(8, id);
			updateStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in Update:" + e.getMessage());
			e.printStackTrace();
		}
		return updateStatus;

	}

	@Override
	public int delete(int customerID) {
		String deleteQuery = "delete from  cust1  where cust_id=?";
		int deleteStatus = 0;
		try {
			p = con.prepareStatement(deleteQuery);
			p.setInt(1, customerID);
			deleteStatus = p.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in delete:" + e.getMessage());
		}
		return deleteStatus;
	}

	public int gettId(int aadhar) {
		int id=0;
		String sql = "select cust_id from cust1 where aadhar=?";
		try {
			p = con.prepareStatement(sql);
			p.setInt(1, aadhar);
			rs = p.executeQuery();
			while(rs.next())
			{
				id=rs.getInt("cust_id");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;

	}

}
